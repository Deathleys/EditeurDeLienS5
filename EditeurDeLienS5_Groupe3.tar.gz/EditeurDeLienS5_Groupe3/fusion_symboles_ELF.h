#ifndef FUSION_SYMBOLES_ELF_H
#define FUSION_SYMBOLES_ELF_H

#include "type.h"

Liste_Sym * copier_liste_symboles (donnees_ELF ELF) ;

bool fusion_table_symboles (donnees_ELF ELF1, donnees_ELF ELF2, donnees_ELF ELF3, bool *b) ;

#endif
