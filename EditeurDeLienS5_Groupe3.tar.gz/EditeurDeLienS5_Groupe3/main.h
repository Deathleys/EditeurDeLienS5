#ifndef MAIN_H
#define MAIN_H

#include "debug.h"
#include "type.h"
#include "lecture_fichier_ELF.h"
#include "affichage_ELF.h"
#include "fusion_progbits_ELF.h"
#include "fusion_symboles_ELF.h"

struct option longopts[] = {
		{ "help", no_argument, NULL, 'H' },
		{ "debug", required_argument, NULL, 'd' },
		{ "fichier1", required_argument, NULL, '1' },
		{ "fichier2", required_argument, NULL, '2' },
		{ "entete", no_argument, NULL, 'h' },
		{ "sections", no_argument, NULL, 'S' },		
		{ "sections_contenu", required_argument, NULL, 'x' },
		{ "sections_contenus", no_argument, NULL, 'X' },
		{ "symbole", no_argument, NULL, 's' },	
		{ "tables_reimplantation", no_argument, NULL, 'r' },	
		{ "fusion", required_argument, NULL, 'f' },	
		{ "construction", required_argument, NULL, 'c' },
		{ NULL, 0, NULL, 0 }
};

void usage(char *name);

void initialiser_descripteur(FILE **f, char * nom_fichier, char *mode);

void delivrer(FILE **f, donnees_ELF *ELF, char **Donnees_ELF);

void construire_fichier(donnees_ELF ELF, char* nom_fichier);

#endif
