#ifndef FUSION_PROGBITS_ELF_H
#define FUSION_PROGBITS_ELF_H

#include "type.h"
#include "affichage_ELF.h"

char* get_nom_section(donnees_ELF ELF, int i);

//Reporte les décalages de chaque section pour reconstruction correcte.
void ajouter_nom_section(donnees_ELF ELF, char* nom);

//Ajoute un nom à la table des noms de sections
void decalage_sections_suivantes(donnees_ELF ELF, int decalage, int i);

//Lorsque une section progbits est présente dans ELF2 (et pas dans ELF1/ELF3), la procédure ajoute cette section à la fin des sections de ELF3 
void ajout_section_progbits(donnees_ELF ELF1, donnees_ELF ELF2, donnees_ELF ELF3);

//Lorsque deux sections progbits de même nom sont présentes dans ELF1 et ELF2, la procédure concatène dans ELF3 
//à la fin de la section en question (identique à celle de ELF1) le contenu de celle de de ELF2
void concatenation_section_progbits(donnees_ELF ELF1, donnees_ELF ELF2, donnees_ELF ELF3);

//fusionne dans ELF3 (identique à ELF1 au départ) les sections de type progbits de ELF1 et ELF2
void fusion_progbits(donnees_ELF ELF1, donnees_ELF ELF2, donnees_ELF ELF3);

#endif
