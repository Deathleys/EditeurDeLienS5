#include "fusion_symboles_ELF.h"

// Pseudo-Code de l'Algorithme de la fusion des tables de symboles

/*

Liste=table2
nbSymboleTable1=table1.nbSymbole
nbSymboleListe=table2.nbSymbole
table symbole (nouvelleTable)
nbSymbNouvelle=0

Pour i allant de 1 à nbSymboleTable1

	Si table1[i].lien=LOCAL				                                    // Symboles LOCAUX => on les stocke 
		Ajouter(nouvelleTable,table1[i])
		nbSymbNouvelle+1
		
	Sinon Si table1[i].lien=GLOBAL				
		Pour j allant de 1 à nbSymboleListe
			Si table1[i].name=table2[j].name
				Si !table1[i].ndx=UND && !table2[j].ndx=UND 				// mêmes noms et définis => on arrête l'édition des liens
					Afficher("Erreur, impossible de linker")
					ToutLiberer
					ArreterProgramme
				Sinon si table1[i].ndx=UND && !table2[j].ndx=UND			// mêmes noms , un seul défini => on garde le symbole défini
					Ajouter(nouvelleTable,table2[j])
				Sinon si !table1[i].ndx=UND && table2[j].ndx=UND			// mêmes noms , un seul défini => on garde le symbole défini
					Ajouter(nouvelleTable,table1[i])				
				Sinon 														// mêmes noms, non définis => on garde un symbole défini
					Ajouter(nouvelleTable,table1[i])
				EnleverElémentListe(Liste[j])
				nbSymboleBuffer-1
				nbSymbNouvelle+1
				
																			// Remarque : on garde TOUJOURS un seul symbole GLOBAL
Pour j allant de 1 à nbSymboleBuffer+1
	Ajouter(nouvelleTable,table2[j])
	nbSymbNouvelle+1

*/

// Début de l'implantation

bool fusion_table_symboles (donnees_ELF ELF1, donnees_ELF ELF2, donnees_ELF ELF3, bool *b) {
	
	bool alloc = false ;
	
	/**Liste_Sym *CL, *CG, *tmp ;
	
	Elf32_Sym ** Tables_Symboles ;
	
	
	Liste_Sym *FL = malloc (sizeof *FL) ;
	Liste_Sym *FG = malloc (sizeof *FG) ;
	
	if (FL && FG) {
		
		CL = FL ; CL->succ = ELF2->Liste_Sym_Loc ; FL->succ = CL->succ ;
		CG = FG ; CG->succ = ELF2->Liste_Sym_Glo ; FG->succ = CG->succ ;
	
		while (FL->succ) {
				
			ELF1->Table_Symboles = realloc (ELF1->Table_Symboles,  sizeof (Elf32_Sym *) * (ELF1->lts + 1)) ;
			Table_Symboles[i] = malloc (sizeof (Elf32_Sym)) ;
			memcpy(Table_Symboles[i], ELF1->Table_Symboles[ELF1->lts],  sizeof (Elf32_Sym)) ;
			ELF1->Table_Symboles[i]->st_shndx = ELF->lts ;
			ELF1->lts++ ;
				
			tmp = CL->succ ;
			CL->succ = tmp->succ ;
			free (tmp) ;
				
		}
		
		free (FL) ;
		
		while (FG->succ && *b) {
		
			Liste_Sym * CG1 = ELF1->Liste_Sym_Glo ;
			
			while (CG1 && strcmp(ELF1->Table_Chaines + ELF1->Table_Symboles[CG1->succ->ind]->st_name, ELF2->Table_Chaines + ELF2->Table_Symboles[CG->succ->ind]->st_name)) CG1 = CG1->succ ;
			
			if (!strcmp(ELF1->Table_Chaines + ELF1->Table_Symboles[CG1->succ->ind]->st_name, ELF2->Table_Chaines + ELF2->Table_Symboles[CG->succ->ind]->st_name) {
				
				if (ELF1->Table_Symboles[i]->st_shndx != SHN_UNDEF && AC->sym->st_shndx != SHN_UNDEF) *b = false ;
				
				else if (ELF1->Table_Symboles[i]->st_shndx == SHN_UNDEF && AC->sym->st_shndx != SHN_UNDEF) {
							
					Table_Symboles = realloc (Table_Symboles,  sizeof (Elf32_Sym *) * (ELF3->lts + 1)) ;
					Table_Symboles[i] = malloc (sizeof (Elf32_Sym)) ;
					memcpy(Table_Symboles[i], AC->sym,  sizeof (Elf32_Sym)) ;
							
				}
						
				else {
							
					Table_Symboles = realloc (Table_Symboles,  sizeof (Elf32_Sym *) * (ELF3->lts + 1)) ;
					Table_Symboles[i] = malloc (sizeof (Elf32_Sym)) ;
					memcpy(Table_Symboles[i], ELF1->Table_Symboles[i],  sizeof (Elf32_Sym)) ;
							
				}
						
						lts++ ;
						
						
						
						
					}
					
					AC = AC->succ ;
					
				}
				
			}
			
		}
		
	}
						
						
	AC = L2 ;
	
	
	
	while (L2) {
		
		Liste_Sym *tmp = L2 ;
		L2 = L2->succ ;
		free (tmp->sym) ;
		free (tmp) ;
		
	} */
	
	return alloc ;
		
}
