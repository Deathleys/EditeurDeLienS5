#include <getopt.h>
#include "main.h"

void usage(char *name) {
	fprintf(stderr, "Usage:\n"
		"%s [ --help ] [ --fichier1 nom_de_fichier ] [ --fichier2 nom_de_fichier ] [ --entete ] [ --sections ] [ --sections_contenu nom_ou_numero_de_section ] [ --sections_contenus ] [ --symbole ] [ --tables_reimplantation ] [ --fusion nom_de_fichier ] [ --construction nom_de_fichier ] \n\n"
		"Simule le comportement de la commande ReadElf et implémente une sous partie d'éditeur de liens.\n"
		"[-1<nom_fichier>] : met en mémoire le contenu du fichier objet translatable <nom_fichier> (information requise) (chemin relatif) si présent\n"
		"[-2<nom_fichier>] : met en mémoire le contenu du fichier objet translatable <nom_fichier> (information requise) (chemin relatif) si présent\n"
		"[-H] : affiche les options du programme fusionL3G3 (usage)\n"
		"[-d] : active le flag debug\n"
		"[-h] : affiche l'entête du fichier 1 (si présent) (cf phase 1 étape 1)\n"
		"[-S] : affiche la table des sections du fichier 1 (si présent) (cf phase 1 étape 2)\n"
		"[-x<number_or_name>] : affiche le contenu d’une section du fichier 1 (si présent) number_or_name (information requise) peut être l’index ou le nom de section. (cf phase 1 étape 3)\n"
		"[-X] : affiche le contenu de toutes les sections du fichier 1 (si présent)\n"
		"[-s] : affiche la table des symboles du fichier 1 (si présent) (cf phase 1 étape 4)\n"
		"[-r] : affiche la table des relocations du fichier 1 (si présent) (cf phase 1 étape 5)\n"
		"[-f] : réalise la fusion entre les fichiers 1 et 2 (si présents) (cf phase 2 étape 6-8)\n"
		"[-c<nom_fichier>] : reconstruit le fichier 1 (si présent) (cf phase 2 étape 9) au format ELF sous le nom nom_fichier (produit à la racine)\n\n",name );	
}

//initialise un descripteur de fichier
void initialiser_descripteur(FILE **f, char * nom_fichier, char *mode){
	*f = fopen(nom_fichier, mode) ;	
	if (*f==NULL){
		fprintf(stderr, "Le fichier %s n'a pas pu être ouvert.\n", nom_fichier) ;
		exit(1);
	}	
}

//initialise une structure de données ELF
donnees_ELF initialiser_donnees_ELF () {
	donnees_ELF ELF = malloc (sizeof *ELF) ;
	if (ELF) {
		ELF->Entete_ELF = NULL ;             // stocke l'en-tête du fichier ELF
	        ELF->Entete_Programme = NULL ;       // stocke l'en-tête du programme (optionnel)
		ELF->Entetes_Sections = NULL ;       // stocke les en-têtes de section
		ELF->Table_Symboles = NULL ;         // stocke les symboles de type Elf32_Sym 
		ELF->Table_Rel = NULL ;              // stocke les entrées de section de type Elf32_Rel
		ELF->Table_Progbits = NULL ;         // stocke les entrées de section de type Elf32_Rel
	
		ELF->Table_Chaines_ES = NULL ;       // table des chaines des noms des entêtes de section (.shstrtab)
		ELF->Table_Chaines = NULL ;          // table des chaines des noms de symbole (.strtab)
		ELF->Sections = NULL ;               // stocke le contenu des sections
	
		ELF->les = 0 ;                       // nombre d'en-têtes de section (ou nombre de sections) 
		ELF->lts = 0 ;			     // nombre de symboles
		ELF->taille = 0;		     // taille du fichier ELF
	}else {
		ELF = NULL;
		fprintf(stderr, "La structure ELF n'a pas pu être allouée\n") ;
	}
	return ELF ;
}

//produit un fichier objet translatable au format ELF de nom nom_fichier équivalent au contenu de la structure ELF
void construire_fichier(donnees_ELF ELF, char* nom_fichier) {
	FILE* f = NULL;
	initialiser_descripteur(&f,nom_fichier, "w");

	fwrite(ELF->Entete_ELF , 1 , sizeof(Elf32_Ehdr) , f );
	for(int i=0; i<ELF->les; i++) {
		fseek(f,ELF->Entetes_Sections[i]->sh_offset,SEEK_SET);
		fwrite(ELF->Sections[i] ,1 , ELF->Entetes_Sections[i]->sh_size , f);
	}
	fseek(f,ELF->Entete_ELF->e_shoff,SEEK_SET);
	for(int i=0; i<ELF->les; i++)
		fwrite(ELF->Entetes_Sections[i] ,1 , sizeof(Elf32_Shdr) , f);
	printf("\nConstruction de %s terminé.\n\n", nom_fichier);

	if(f != NULL){
		fclose(f) ;
		f=NULL;
	}
}

//libère l'intégralité d'une structure donnees_ELF * au besoin
void liberer_donnees_ELF (donnees_ELF *ELF, char **Donnees_ELF) {
	if (*Donnees_ELF != NULL) {
		free(*Donnees_ELF) ;
		*Donnees_ELF = NULL ;
	}
	
	if (*ELF != NULL) {
		while ((*ELF)->Table_Rel) {
			Section_Rel *tmp = (*ELF)->Table_Rel ;
			(*ELF)->Table_Rel = (*ELF)->Table_Rel->succ ;
			free(tmp) ;
		}
		
		while ((*ELF)->Table_Progbits) {
			Section_Progbits *tmp = (*ELF)->Table_Progbits ;
			(*ELF)->Table_Progbits = (*ELF)->Table_Progbits->succ ;
			free(tmp) ;
		}
		
		for(int i =0; i<(*ELF)->les;i++)
			if ((*ELF)->Entetes_Sections) 
				free((*ELF)->Entetes_Sections[i]) ;

		if ((*ELF)->Entetes_Sections) free((*ELF)->Entetes_Sections) ;

		for(int i =0; i<(*ELF)->les;i++)
			if ((*ELF)->Sections) free((*ELF)->Sections[i]) ;
		
		if ((*ELF)->Sections) free((*ELF)->Sections) ;

		if ((*ELF)->Table_Symboles)  free((*ELF)->Table_Symboles) ;

		if ((*ELF)->Table_Chaines_ES)  free((*ELF)->Table_Chaines_ES) ;

		if ((*ELF)->Table_Chaines)  free((*ELF)->Table_Chaines) ;

		free(*ELF) ;
		*ELF = NULL ;
	}	
}

//ferme un descripteur et la structure associée au besoin
void delivrer(FILE **f, donnees_ELF *ELF, char **Donnees_ELF_fich){
	if(*f != NULL){
		fclose(*f) ;
		*f=NULL;
	}
	liberer_donnees_ELF(ELF, Donnees_ELF_fich) ;
}

int main (int argc, char **argv) {
	int opt;
	char *nom_fichier1 = NULL , *nom_fichier2 = NULL , *nom_fichier3 = NULL, *nom_section = NULL;
	FILE *f1 = NULL, *f2 = NULL, *f3 = NULL;
	char *Donnees_ELF_fich1 = NULL, *Donnees_ELF_fich2 = NULL, *Donnees_ELF_fich3 = NULL ;
	donnees_ELF ELF1 = NULL, ELF2 = NULL, ELF3 = NULL ;

	while ((opt = getopt_long(argc, argv, "Hd:1:2:hSx:Xsrf:c:", longopts, NULL)) != -1) {
		switch(opt) {
			case 'd':
				add_debug_to(optarg);
				break;
			case '1':
				nom_fichier1 = optarg;
				initialiser_descripteur(&f1,nom_fichier1, "r");
				lecture_fichier_ELF(&ELF1, &Donnees_ELF_fich1, f1, nom_fichier1) ;
				break;
			case '2':
				nom_fichier2 = optarg;
				initialiser_descripteur(&f2,nom_fichier2, "r");
				lecture_fichier_ELF(&ELF2, &Donnees_ELF_fich2, f2, nom_fichier2) ;
				break;

			case 'h':
				printf("\nAffichage de l'en-tête (Similaire à readelf -h) demandé.\n\n");
				if(ELF1!=NULL){
					afficher_entete_ELF (ELF1->Entete_ELF) ;
					printf("\n") ;
				}
				delivrer(&f1,&ELF1, &Donnees_ELF_fich1);
				exit(0);
			case 'S':
				printf("\nAffichage de la table des sections (Similaire à readelf -S) demandé.\n\n");
				if(ELF1!=NULL){
					afficher_entetes_section (ELF1) ;
					printf("\n") ;
				}
				delivrer(&f1,&ELF1, &Donnees_ELF_fich1);
				exit(0);
			case 'x':
				printf("\nAffichage du contenu de la section %s (Similaire à readelf -x nom_num_Section).\n\n",nom_section);
				if(ELF1!=NULL){
					nom_section = optarg;
					afficher_contenus_section(ELF1, nom_section);
					printf("\n") ;
				}
				delivrer(&f1,&ELF1, &Donnees_ELF_fich1);
				exit(0);
			case 'X':
				printf("\nAffichage des contenus de toutes les sections de %s demandé.\n\n", nom_fichier1);		
				if(ELF1!=NULL){
					char indice_test[ELF1->les];
					for(int i=0;i<ELF1->les;i++){
						sprintf(indice_test,"%d",i);
						afficher_contenus_section (ELF1, indice_test) ;
					}
					printf("\n") ;
				}
				delivrer(&f1,&ELF1, &Donnees_ELF_fich1);
				exit(0);
			case 's':
				printf("\nAffichage de la table des symboles (Similaire à readelf -s) demandé.\n\n");
				if(ELF1!=NULL){
					afficher_table_symboles (ELF1) ;
					printf("\n\n") ;
				}
				delivrer(&f1,&ELF1, &Donnees_ELF_fich1);
				exit(0);
			case 'r':
				printf("\nAffichage de la table de réimplantation (Similaire à readelf -r) demandé.\n\n");
				if(ELF1!=NULL){
					afficher_sections_reimplantation (ELF1) ;
					printf("\n\n") ;
				}
				delivrer(&f1,&ELF1, &Donnees_ELF_fich1);
				exit(0);
			case 'f':
				printf("\nFusion des fichiers demandée.\n");
				if(ELF1!=NULL && ELF2!=NULL){	
					initialiser_descripteur(&f3,nom_fichier1, "r");
					lecture_fichier_ELF(&ELF3, &Donnees_ELF_fich3, f3, nom_fichier1);

					fusion_progbits(ELF1, ELF2, ELF3);

					nom_fichier3 = optarg;
					construire_fichier(ELF3, nom_fichier3);;
				}
				delivrer(&f1,&ELF1, &Donnees_ELF_fich1);
				delivrer(&f2,&ELF2, &Donnees_ELF_fich2);
				delivrer(&f3,&ELF3, &Donnees_ELF_fich3);
				exit(0);
			case 'c':
				printf("\nReconstruction du fichier demandée.\n");
				if(ELF1!=NULL){
					nom_fichier3 = optarg;
					construire_fichier(ELF1, nom_fichier3);
				}
				delivrer(&f1,&ELF1, &Donnees_ELF_fich1);
				exit(0);
			case 'H':
				usage(argv[0]);
				break;
			default:
				fprintf(stderr, "Option %c non reconnue.\n", opt);
				usage(argv[0]);
				exit(1);
			}
	}
	delivrer(&f1,&ELF1, &Donnees_ELF_fich1);
	delivrer(&f2,&ELF2, &Donnees_ELF_fich2);
	delivrer(&f3,&ELF3, &Donnees_ELF_fich3);
	
	return EXIT_SUCCESS ;	
}
