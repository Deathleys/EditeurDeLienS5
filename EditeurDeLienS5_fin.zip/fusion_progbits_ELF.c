#include "fusion_progbits_ELF.h"

char* get_nom_section(donnees_ELF ELF, int i) {
	return ELF->Table_Chaines_ES + ELF->Entetes_Sections[i]->sh_name ;	
}

//Reporte les décalages de chaque section pour reconstruction correcte.
void decalage(donnees_ELF ELF){
	//Départ des sections à la suite de l'entête
	int offset_suivant = ELF->Entete_ELF->e_ehsize;

	//Modification de l'offset de l'en-tête de programme
	ELF->Entete_ELF->e_phoff = offset_suivant;
	offset_suivant = ELF->Entete_ELF->e_phoff + (ELF->Entete_ELF->e_phnum * ELF->Entete_ELF->e_phentsize);
	
	//Modification de l'offset des sections
	for(int i = 0; i < ELF->les; i++){
		ELF->Entetes_Sections[i]->sh_offset = offset_suivant;
		offset_suivant = ELF->Entetes_Sections[i]->sh_offset + ELF->Entetes_Sections[i]->sh_size;
	}

	//Modification de l'offset des en-têtes de section
	ELF->Entete_ELF->e_shoff = offset_suivant;
	offset_suivant = ELF->Entete_ELF->e_shoff + (ELF->les * ELF->Entete_ELF->e_shentsize);
}

//Ajoute un nom à la table des noms de sections
void ajouter_nom_section(donnees_ELF ELF, char* nom_section){
	int longueur_nom = strlen(nom_section) + 1;
	char* nom = malloc(longueur_nom);
	strcpy(nom, nom_section);

	int taille = ELF->Entetes_Sections[ELF->Entete_ELF->e_shstrndx]->sh_size;
	int nouvelle_taille = taille + longueur_nom;

	//Agrandissment de la table des noms en mémoire dans la structure
	ELF->Table_Chaines_ES = (char *) realloc(ELF->Table_Chaines_ES, nouvelle_taille);

	//Ajout du nom dans la table des noms en mémoire dans la structure
	for (int i = taille; i < nouvelle_taille-1; i++){
		ELF->Table_Chaines_ES[i] = nom[i-taille];
	}
	ELF->Table_Chaines_ES[nouvelle_taille-1] = '\0';

	//Modification de la taille de la table des noms dans l'entête_ELF
	ELF->Entetes_Sections[ELF->Entete_ELF->e_shstrndx]->sh_size = nouvelle_taille;

	//Changement de l'indice sh_name de la section pour retrouver le nom dans la table des noms
	ELF->Entetes_Sections[ELF->les-1]->sh_name = taille;

	//Agrandissment de la section table des noms
	ELF->Sections[ELF->Entete_ELF->e_shstrndx] = realloc(ELF->Sections[ELF->Entete_ELF->e_shstrndx], nouvelle_taille);
	//Push de la table des noms en mémoire dans la strucutre dans la section concernée
	memcpy(ELF->Sections[ELF->Entete_ELF->e_shstrndx], ELF->Table_Chaines_ES, nouvelle_taille);
}

//Lorsque une section progbits est présente dans ELF2 (et pas dans ELF1/ELF3), la procédure ajoute cette section à la fin des sections de ELF3 
void ajout_section_progbits(donnees_ELF ELF1, donnees_ELF ELF2, donnees_ELF ELF3){
	for(int i = 0; i < ELF2->les; i++) {
		int trouve = 0;
		if(ELF2->Entetes_Sections[i]->sh_type == SHT_PROGBITS) {
			for(int j = 0; j < ELF1->les; j++) {
				if(ELF1->Entetes_Sections[j]->sh_type == SHT_PROGBITS && strcmp(get_nom_section(ELF1, j),get_nom_section(ELF2, i))==0)
					trouve = 1;
			}
			
			// La section i de ELF2 n'est pas dans ELF1/ELF3
			if (trouve == 0){
				//Ajout de l'entrée En-tête_de_section de ELF3 
				ELF3->Entetes_Sections = (Elf32_Shdr **) realloc(ELF3->Entetes_Sections, sizeof (Elf32_Shdr) * (ELF3->les + 1));
				Elf32_Shdr *nouvelle_section = malloc(sizeof(Elf32_Shdr));
				*nouvelle_section = *(ELF2->Entetes_Sections[i]);
				ELF3->Entetes_Sections[ELF3->les] = nouvelle_section;
				
				//Ajout de l'entrée Contenu_de_section dans ELF3
				ELF3->Sections = (char **) realloc(ELF3->Sections, sizeof(char *) * (ELF3->les + 1));
				ELF3->Sections[ELF3->les] = malloc(ELF3->Entetes_Sections[ELF3->les]->sh_size);
				memcpy(ELF3->Sections[ELF3->les], ELF2->Sections[i], ELF3->Entetes_Sections[ELF3->les]->sh_size);
				
				//Incrémentation du nombre d'entête et de sections dans l'entête_ELF de ELF3
				ELF3->les = ELF3->les + 1;
				ELF3->Entete_ELF->e_shnum = ELF3->Entete_ELF->e_shnum + 1;
				
				//Ajout du nom de section dans la table des noms de ELF3
				ajouter_nom_section(ELF3, get_nom_section(ELF2, i));			
			}
		}
	}
	
}

//Lorsque deux sections progbits de même nom sont présentes dans ELF1 et ELF2, la procédure concatène dans ELF3 
//à la fin de la section en question (identique à celle de ELF1) le contenu de celle de de ELF2
void concatenation_section_progbits(donnees_ELF ELF1, donnees_ELF ELF2, donnees_ELF ELF3){

	for(int i = 0; i < ELF1->les; i++) {
		if(ELF1->Entetes_Sections[i]->sh_type == SHT_PROGBITS) {
			for(int j = 0; j < ELF2->les; j++) {
				if(ELF2->Entetes_Sections[j]->sh_type == SHT_PROGBITS && strcmp(get_nom_section(ELF1, i),get_nom_section(ELF2, j))==0) {

					//Concaténer la section donnée de ELF2, à la fin la même section dans ELF3, si cette première n'est pas nulle
					if (ELF2->Entetes_Sections[j]->sh_size != 0){

						ELF3->Entetes_Sections[i]->sh_size += ELF2->Entetes_Sections[j]->sh_size; // modification de la taille stockée pour cettte section dans ELF3 dans ses entetes de sections

						ELF3->Sections[i] = realloc(ELF3->Sections[i], ELF3->Entetes_Sections[i]->sh_size ); // réallocation de la zone allouée au stockage de cette section dans ELF3

						memcpy(ELF3->Sections[i] + ELF1->Entetes_Sections[i]->sh_size,ELF2->Sections[j],ELF2->Entetes_Sections[j]->sh_size); //copie des données de ELF2 à la suite de celle de ELF1 déjà en mémoire				
					}
				}
			}
		}
	}
}

//fusionne dans ELF3 (identique à ELF1 au départ) les sections de type progbits de ELF1 et ELF2
void fusion_progbits(donnees_ELF ELF1, donnees_ELF ELF2, donnees_ELF ELF3) {
	concatenation_section_progbits(ELF1, ELF2, ELF3);
	ajout_section_progbits(ELF1, ELF2, ELF3);
	decalage(ELF3);
}

