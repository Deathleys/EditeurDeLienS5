#ifndef MAIN_H
#define MAIN_H

#include "debug.h"
#include "type.h"
#include "lecture_fichier_ELF.h"
#include "affichage_ELF.h"
#include "fusion_progbits_ELF.h"
#include "fusion_symboles_ELF.h"

void usage(char *name); 

void initialiser_descripteur(FILE **f, char * nom_fichier, char *mode);

void delivrer(FILE **f, donnees_ELF *ELF, char **Donnees_ELF);

#endif
